r=5
p=3
A=p*r
B=A
C=2*p
D=B+7
E=9
if (E == 7):
    E=10
